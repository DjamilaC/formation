// alert('hello');
$(function (){
    //   ici tout le code js et jQuery ici
    // ca s'appelle le scope jQuery
    console.log('DOM et jQuery bien charge : ');
})

<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = [];
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_wdt']), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_search_results']), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler']), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_router']), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception']), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => '_profiler_exception_css']), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, ['_route' => '_twig_error_test']), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        elseif (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/produit')) {
                // admin_produit
                if ('/admin/produit' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminProduitAction',  '_route' => 'admin_produit',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_produit;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_produit'));
                    }

                    return $ret;
                }
                not_admin_produit:

                // admin_produit_add
                if ('/admin/produit/add' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminProduitAddAction',  '_route' => 'admin_produit_add',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_produit_add;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_produit_add'));
                    }

                    return $ret;
                }
                not_admin_produit_add:

                // admin_produit_update
                if (0 === strpos($pathinfo, '/admin/produit/update') && preg_match('#^/admin/produit/update/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_produit_update']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminProduitUpdateAction',));
                }

                // admin_produit_delete
                if (0 === strpos($pathinfo, '/admin/produit/delete') && preg_match('#^/admin/produit/delete/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_produit_delete']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminProduitDeleteAction',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_produit_delete;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_produit_delete'));
                    }

                    return $ret;
                }
                not_admin_produit_delete:

            }

            elseif (0 === strpos($pathinfo, '/admin/membre')) {
                // admin_membre
                if ('/admin/membre' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminMembreAction',  '_route' => 'admin_membre',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_membre;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_membre'));
                    }

                    return $ret;
                }
                not_admin_membre:

                // admin_membre_add
                if ('/admin/membre/add' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminMembreAddAction',  '_route' => 'admin_membre_add',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_membre_add;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_membre_add'));
                    }

                    return $ret;
                }
                not_admin_membre_add:

                // admin_membre_update
                if (0 === strpos($pathinfo, '/admin/membre/update') && preg_match('#^/admin/membre/update/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_membre_update']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminMembreUpdateAction',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_membre_update;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_membre_update'));
                    }

                    return $ret;
                }
                not_admin_membre_update:

                // admin_membre_delete
                if (0 === strpos($pathinfo, '/admin/membre/delete') && preg_match('#^/admin/membre/delete/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_membre_delete']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminMembreDeleteAction',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_membre_delete;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_membre_delete'));
                    }

                    return $ret;
                }
                not_admin_membre_delete:

            }

            elseif (0 === strpos($pathinfo, '/admin/commande')) {
                // admin_commande
                if ('/admin/commande' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminCommandeAction',  '_route' => 'admin_commande',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_commande;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_commande'));
                    }

                    return $ret;
                }
                not_admin_commande:

                // admin_commande_add
                if ('/admin/commande/add' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminCommandeAddAction',  '_route' => 'admin_commande_add',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_commande_add;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_commande_add'));
                    }

                    return $ret;
                }
                not_admin_commande_add:

                // admin_commande_update
                if (0 === strpos($pathinfo, '/admin/commande/update') && preg_match('#^/admin/commande/update/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_commande_update']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminCommandeUpdateAction',));
                }

                // admin_commande_delete
                if (0 === strpos($pathinfo, '/admin/commande/delete') && preg_match('#^/admin/commande/delete/(?P<id>[^/]++)/?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, ['_route' => 'admin_commande_delete']), array (  '_controller' => 'AppBundle\\Controller\\AdminController::adminCommandeDeleteAction',));
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not_admin_commande_delete;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', 'admin_commande_delete'));
                    }

                    return $ret;
                }
                not_admin_commande_delete:

            }

        }

        // inscription
        if ('/inscription' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\MembreController::inscriptionAction',  '_route' => 'inscription',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_inscription;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'inscription'));
            }

            return $ret;
        }
        not_inscription:

        // connexion
        if ('/connexion' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\MembreController::connexionAction',  '_route' => 'connexion',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_connexion;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'connexion'));
            }

            return $ret;
        }
        not_connexion:

        // categorie
        if (0 === strpos($pathinfo, '/categorie') && preg_match('#^/categorie/(?P<cat>[^/]++)$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, ['_route' => 'categorie']), array (  '_controller' => 'AppBundle\\Controller\\ProduitController::categorieAction',));
        }

        // profil
        if ('/profil' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\MembreController::profilAction',  '_route' => 'profil',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_profil;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'profil'));
            }

            return $ret;
        }
        not_profil:

        // produit
        if (0 === strpos($pathinfo, '/produit') && preg_match('#^/produit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, ['_route' => 'produit']), array (  '_controller' => 'AppBundle\\Controller\\ProduitController::produitAction',));
        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\ProduitController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
